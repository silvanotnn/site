@extends('layouts.public')

@section('title', 'Álbuns de Fotos')

@section('content')
<!-- Hero Section -->
<section class="hero-section" style="background: linear-gradient(rgba(31, 41, 55, 0.7), rgba(31, 41, 55, 0.7)), url('https://images.unsplash.com/photo-1574629810360-7efbbe195018?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1493&q=80');">
    <div class="container mx-auto px-4">
        <div class="hero-content text-center" data-aos="fade-up">
            <h1 class="hero-title">Álbuns de Fotos</h1>
            <p class="hero-subtitle">Confira os momentos especiais e atividades da nossa escola através de nossas galerias de fotos</p>
        </div>
    </div>
</section>

<!-- Albums List Section -->
<section class="section">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            @if(isset($albums) && count($albums) > 0)
                @foreach($albums as $album)
                <div class="card" data-aos="fade-up" data-aos-delay="{{ $loop->iteration * 100 }}">
                    <div class="h-56 bg-gray-300 flex items-center justify-center">
                        @if(isset($album->images) && count($album->images) > 0)
                            <img src="{{ asset('storage/' . $album->images[0]->path) }}" alt="{{ $album->name }}" class="w-full h-full object-cover">
                        @else
                            <div class="w-full h-full bg-blue-100 flex items-center justify-center">
                                <i class="fas fa-images text-4xl text-blue-500"></i>
                            </div>
                        @endif
                    </div>
                    <div class="p-6">
                        <h3 class="card-title text-xl">{{ $album->name }}</h3>
                        <div class="flex items-center text-gray-500 text-sm mb-3">
                            <span class="mr-4">
                                <i class="far fa-calendar-alt mr-1"></i>
                                {{ $album->created_at->format('d/m/Y') }}
                            </span>
                            @if(isset($album->images))
                            <span>
                                <i class="far fa-images mr-1"></i>
                                {{ count($album->images) }} fotos
                            </span>
                            @endif
                        </div>
                        <p class="card-text mb-4">{{ \Illuminate\Support\Str::limit($album->description, 100) }}</p>
                        <a href="{{ route('albums.show', $album->id) }}" class="btn-primary inline-block">Ver álbum</a>
                    </div>
                </div>
                @endforeach
            @else
                <div class="col-span-3 text-center py-12" data-aos="fade-up">
                    <div class="bg-white rounded-lg shadow-md p-8">
                        <i class="fas fa-images text-5xl text-gray-300 mb-4"></i>
                        <h3 class="text-xl font-bold text-gray-700 mb-2">Nenhum álbum disponível</h3>
                        <p class="text-gray-600">Volte em breve para conferir nossas galerias de fotos.</p>
                    </div>
                </div>
            @endif
        </div>

        <!-- Pagination -->
        @if(isset($albums) && $albums->hasPages())
        <div class="mt-12 flex justify-center" data-aos="fade-up">
            <nav class="inline-flex rounded-md shadow">
                @if($albums->onFirstPage())
                    <span class="px-4 py-2 bg-gray-200 text-gray-500 rounded-l-md">Anterior</span>
                @else
                    <a href="{{ $albums->previousPageUrl() }}" class="px-4 py-2 bg-white text-blue-600 hover:bg-blue-50 rounded-l-md">Anterior</a>
                @endif
                
                <span class="px-4 py-2 bg-blue-600 text-white">{{ $albums->currentPage() }}</span>
                
                @if($albums->hasMorePages())
                    <a href="{{ $albums->nextPageUrl() }}" class="px-4 py-2 bg-white text-blue-600 hover:bg-blue-50 rounded-r-md">Próxima</a>
                @else
                    <span class="px-4 py-2 bg-gray-200 text-gray-500 rounded-r-md">Próxima</span>
                @endif
            </nav>
        </div>
        @endif
    </div>
</section>

<!-- Featured Photos Section -->
<section class="section bg-light-color">
    <div class="container mx-auto px-4">
        <h2 class="section-title text-center text-3xl mb-12" data-aos="fade-up">Fotos em Destaque</h2>
        
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="100">
                <img src="https://images.unsplash.com/photo-1577896851231-70ef18881754?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" alt="Sala de aula" class="gallery-img">
                <div class="gallery-overlay">
                    <a href="#" class="text-white hover:text-yellow-300">
                        <i class="fas fa-search-plus text-3xl"></i>
                    </a>
                </div>
            </div>
            
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="200">
                <img src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1422&q=80" alt="Estudantes" class="gallery-img">
                <div class="gallery-overlay">
                    <a href="#" class="text-white hover:text-yellow-300">
                        <i class="fas fa-search-plus text-3xl"></i>
                    </a>
                </div>
            </div>
            
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="300">
                <img src="https://images.unsplash.com/photo-1588072432836-e10032774350?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1472&q=80" alt="Biblioteca" class="gallery-img">
                <div class="gallery-overlay">
                    <a href="#" class="text-white hover:text-yellow-300">
                        <i class="fas fa-search-plus text-3xl"></i>
                    </a>
                </div>
            </div>
            
            <div class="gallery-item" data-aos="zoom-in" data-aos-delay="400">
                <img src="https://images.unsplash.com/photo-1574629810360-7efbbe195018?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1493&q=80" alt="Quadra esportiva" class="gallery-img">
                <div class="gallery-overlay">
                    <a href="#" class="text-white hover:text-yellow-300">
                        <i class="fas fa-search-plus text-3xl"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Share Photos CTA -->
<section class="section bg-primary-color text-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-6" data-aos="fade-up">Compartilhe seus momentos</h2>
        <p class="text-xl mb-8 max-w-3xl mx-auto" data-aos="fade-up" data-aos-delay="100">Você é parte da comunidade escolar? Compartilhe suas fotos dos eventos e atividades da Escola Vista Alegre conosco.</p>
        <a href="{{ route('contact') }}" class="inline-block bg-white text-primary-color font-bold py-3 px-8 rounded-lg hover:bg-yellow-300 hover:text-primary-dark transition transform hover:-translate-y-1" data-aos="fade-up" data-aos-delay="200">Entre em contato</a>
    </div>
</section>
@endsection
