@extends('layouts.public')

@section('title', 'Sobre')

@section('content')
<!-- Hero Section -->
<section class="hero-section" style="background: linear-gradient(rgba(31, 41, 55, 0.7), rgba(31, 41, 55, 0.7)), url('https://images.unsplash.com/photo-1577896851231-70ef18881754?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80');">
    <div class="container mx-auto px-4">
        <div class="hero-content text-center" data-aos="fade-up">
            <h1 class="hero-title">Sobre Nossa Escola</h1>
            <p class="hero-subtitle">Conheça nossa história, missão, visão e valores</p>
        </div>
    </div>
</section>

<!-- About Section -->
<section class="section">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div data-aos="fade-right">
                <div class="relative">
                    <div class="bg-blue-100 rounded-lg h-80 w-full"></div>
                    <div class="absolute inset-0 transform translate-x-4 translate-y-4">
                        <img src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1422&q=80" alt="Escola Vista Alegre" class="rounded-lg shadow-lg h-80 w-full object-cover">
                    </div>
                </div>
            </div>
            <div data-aos="fade-left">
                <h2 class="section-title text-3xl">Nossa História</h2>
                <p class="mb-6">
                    @if(isset($about) && $about->content)
                        {!! $about->content !!}
                    @else
                        A Escola Vista Alegre foi fundada em 1995 com o objetivo de oferecer educação de qualidade para crianças e jovens da região. Desde então, temos trabalhado incansavelmente para formar cidadãos conscientes, críticos e preparados para os desafios do mundo contemporâneo.
                        
                        Ao longo desses anos, nossa instituição cresceu e se desenvolveu, sempre mantendo o compromisso com a excelência acadêmica e a formação integral dos alunos. Hoje, somos reconhecidos como uma referência em educação, com uma proposta pedagógica inovadora e uma equipe de profissionais altamente qualificados.
                    @endif
                </p>
                <a href="{{ route('contact') }}" class="btn-primary">Entre em contato</a>
            </div>
        </div>
    </div>
</section>

<!-- Mission, Vision, Values Section -->
<section class="section bg-light-color">
    <div class="container mx-auto px-4">
        <h2 class="section-title text-center text-3xl mb-12" data-aos="fade-up">Missão, Visão e Valores</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="feature-box text-center" data-aos="fade-up" data-aos-delay="100">
                <div class="feature-icon mx-auto">
                    <i class="fas fa-bullseye"></i>
                </div>
                <h3 class="feature-title text-xl">Missão</h3>
                <p>
                    @if(isset($mission) && $mission->content)
                        {!! $mission->content !!}
                    @else
                        Oferecer educação de qualidade, formando cidadãos críticos, éticos e preparados para os desafios do mundo contemporâneo, contribuindo para a construção de uma sociedade mais justa e sustentável.
                    @endif
                </p>
            </div>
            
            <div class="feature-box text-center" data-aos="fade-up" data-aos-delay="200">
                <div class="feature-icon mx-auto">
                    <i class="fas fa-eye"></i>
                </div>
                <h3 class="feature-title text-xl">Visão</h3>
                <p>
                    @if(isset($vision) && $vision->content)
                        {!! $vision->content !!}
                    @else
                        Ser reconhecida como instituição de referência em educação, destacando-se pela excelência acadêmica, inovação pedagógica e formação integral dos alunos.
                    @endif
                </p>
            </div>
            
            <div class="feature-box text-center" data-aos="fade-up" data-aos-delay="300">
                <div class="feature-icon mx-auto">
                    <i class="fas fa-heart"></i>
                </div>
                <h3 class="feature-title text-xl">Valores</h3>
                <p>
                    @if(isset($values) && $values->content)
                        {!! $values->content !!}
                    @else
                        • Ética e respeito<br>
                        • Excelência acadêmica<br>
                        • Inovação e criatividade<br>
                        • Responsabilidade social<br>
                        • Sustentabilidade<br>
                        • Inclusão e diversidade
                    @endif
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Team Section -->
<section class="section">
    <div class="container mx-auto px-4">
        <h2 class="section-title text-center text-3xl mb-12" data-aos="fade-up">Nossa Equipe</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div class="text-center" data-aos="fade-up" data-aos-delay="100">
                <div class="w-40 h-40 rounded-full bg-blue-100 mx-auto mb-4 overflow-hidden">
                    <img src="https://randomuser.me/api/portraits/women/32.jpg" alt="Diretora" class="w-full h-full object-cover">
                </div>
                <h3 class="text-xl font-bold mb-1">Maria Silva</h3>
                <p class="text-gray-600 mb-3">Diretora</p>
                <p class="text-gray-700">Mestre em Educação com mais de 20 anos de experiência.</p>
            </div>
            
            <div class="text-center" data-aos="fade-up" data-aos-delay="200">
                <div class="w-40 h-40 rounded-full bg-blue-100 mx-auto mb-4 overflow-hidden">
                    <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Coordenador Pedagógico" class="w-full h-full object-cover">
                </div>
                <h3 class="text-xl font-bold mb-1">João Santos</h3>
                <p class="text-gray-600 mb-3">Coordenador Pedagógico</p>
                <p class="text-gray-700">Especialista em Psicopedagogia e Gestão Escolar.</p>
            </div>
            
            <div class="text-center" data-aos="fade-up" data-aos-delay="300">
                <div class="w-40 h-40 rounded-full bg-blue-100 mx-auto mb-4 overflow-hidden">
                    <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Coordenadora de Ensino" class="w-full h-full object-cover">
                </div>
                <h3 class="text-xl font-bold mb-1">Ana Oliveira</h3>
                <p class="text-gray-600 mb-3">Coordenadora de Ensino</p>
                <p class="text-gray-700">Doutora em Educação com foco em metodologias ativas.</p>
            </div>
            
            <div class="text-center" data-aos="fade-up" data-aos-delay="400">
                <div class="w-40 h-40 rounded-full bg-blue-100 mx-auto mb-4 overflow-hidden">
                    <img src="https://randomuser.me/api/portraits/men/67.jpg" alt="Coordenador de Tecnologia" class="w-full h-full object-cover">
                </div>
                <h3 class="text-xl font-bold mb-1">Carlos Mendes</h3>
                <p class="text-gray-600 mb-3">Coordenador de Tecnologia</p>
                <p class="text-gray-700">Especialista em Tecnologia Educacional e Inovação.</p>
            </div>
        </div>
    </div>
</section>

<!-- Facilities Section -->
<section class="section bg-light-color">
    <div class="container mx-auto px-4">
        <h2 class="section-title text-center text-3xl mb-12" data-aos="fade-up">Nossa Infraestrutura</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="bg-white rounded-lg shadow-md overflow-hidden" data-aos="fade-right">
                <div class="h-64 bg-gray-300">
                    <img src="https://images.unsplash.com/photo-1588072432836-e10032774350?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1472&q=80" alt="Salas de Aula" class="w-full h-full object-cover">
                </div>
                <div class="p-6">
                    <h3 class="text-xl font-bold mb-3">Salas de Aula</h3>
                    <p class="text-gray-700">Nossas salas de aula são amplas, climatizadas e equipadas com recursos tecnológicos para proporcionar um ambiente de aprendizagem confortável e estimulante.</p>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-md overflow-hidden" data-aos="fade-left">
                <div class="h-64 bg-gray-300">
                    <img src="https://images.unsplash.com/photo-1570975640108-2292d83390d8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" alt="Laboratório de Informática" class="w-full h-full object-cover">
                </div>
                <div class="p-6">
                    <h3 class="text-xl font-bold mb-3">Laboratório de Informática</h3>
                    <p class="text-gray-700">Nosso laboratório de informática conta com computadores modernos e acesso à internet de alta velocidade, permitindo que os alunos desenvolvam habilidades digitais essenciais.</p>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-md overflow-hidden" data-aos="fade-right">
                <div class="h-64 bg-gray-300">
                    <img src="https://images.unsplash.com/photo-1568667256549-094345857637?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" alt="Biblioteca" class="w-full h-full object-cover">
                </div>
                <div class="p-6">
                    <h3 class="text-xl font-bold mb-3">Biblioteca</h3>
                    <p class="text-gray-700">Nossa biblioteca possui um acervo diversificado de livros, revistas e materiais digitais, além de espaços confortáveis para leitura e estudo.</p>
                </div>
            </div>
            
            <div class="bg-white rounded-lg shadow-md overflow-hidden" data-aos="fade-left">
                <div class="h-64 bg-gray-300">
                    <img src="https://images.unsplash.com/photo-1574629810360-7efbbe195018?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1493&q=80" alt="Quadra Esportiva" class="w-full h-full object-cover">
                </div>
                <div class="p-6">
                    <h3 class="text-xl font-bold mb-3">Quadra Esportiva</h3>
                    <p class="text-gray-700">Nossa quadra poliesportiva coberta permite a prática de diversas modalidades esportivas, contribuindo para o desenvolvimento físico e social dos alunos.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="section bg-primary-color text-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-6" data-aos="fade-up">Venha conhecer nossa escola</h2>
        <p class="text-xl mb-8 max-w-3xl mx-auto" data-aos="fade-up" data-aos-delay="100">Agende uma visita e descubra como podemos contribuir para a formação acadêmica e pessoal do seu filho.</p>
        <a href="{{ route('contact') }}" class="inline-block bg-white text-primary-color font-bold py-3 px-8 rounded-lg hover:bg-yellow-300 hover:text-primary-dark transition transform hover:-translate-y-1" data-aos="fade-up" data-aos-delay="200">Agende uma visita</a>
    </div>
</section>
@endsection
