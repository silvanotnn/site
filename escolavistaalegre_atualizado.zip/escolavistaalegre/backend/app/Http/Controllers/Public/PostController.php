<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Post;

class PostController extends Controller
{
    public function index()
    {
        // Buscar todas as postagens paginadas
        $posts = Post::latest()->paginate(9);
        
        return view('public.posts.index', compact('posts'));
    }
    
    public function show(Post $post)
    {
        return view('public.posts.show', compact('post'));
    }
}
