<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Album;

class AlbumController extends Controller
{
    public function index()
    {
        // Buscar todos os álbuns paginados
        $albums = Album::latest()->paginate(9);
        
        return view('public.albums.index', compact('albums'));
    }
    
    public function show(Album $album)
    {
        // Carregar as imagens relacionadas ao álbum
        $album->load('images');
        
        return view('public.albums.show', compact('album'));
    }
}
