# Manual de Instalação e Manutenção - Escola Vista Alegre

## Requisitos do Sistema

- PHP 8.1 ou superior
- Composer
- MySQL 5.7+ ou SQLite 3
- Extensões PHP: BCMath, Ctype, Fileinfo, JSON, Mbstring, OpenSSL, PDO, Tokenizer, XML, Intl, SQLite (se usar SQLite)
- Node.js e NPM (para compilação de assets)
- Servidor web (Apache/Nginx)

## Instalação

### 1. Clonar o Repositório

```bash
git clone [url-do-repositorio] escolavistaalegre
cd escolavistaalegre
```

### 2. Instalar Dependências PHP

```bash
cd backend
composer install
```

### 3. Configurar Variáveis de Ambiente

Copie o arquivo `.env.example` para `.env`:

```bash
cp .env.example .env
```

Edite o arquivo `.env` com as configurações do seu ambiente:

#### Para MySQL:
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=escolavistaalegre
DB_USERNAME=seu_usuario
DB_PASSWORD=sua_senha
```

#### Para SQLite:
```
DB_CONNECTION=sqlite
# Comente ou remova as linhas abaixo
# DB_HOST=127.0.0.1
# DB_PORT=3306
# DB_DATABASE=laravel
# DB_USERNAME=root
# DB_PASSWORD=
```

Se estiver usando SQLite, crie o arquivo do banco de dados:

```bash
touch database/database.sqlite
```

### 4. Gerar Chave da Aplicação

```bash
php artisan key:generate
```

### 5. Executar Migrações

```bash
php artisan migrate
```

### 6. Criar Usuário Administrador (opcional)

```bash
php artisan tinker
```

No console do Tinker:

```php
$user = new \App\Models\User();
$user->name = 'Administrador';
$user->email = 'admin@escolavistaalegre.com.br';
$user->password = Hash::make('senha_segura');
$user->save();
exit;
```

### 7. Configurar Storage para Uploads

```bash
php artisan storage:link
```

### 8. Compilar Assets Frontend

```bash
npm install
npm run build
```

### 9. Configurar Servidor Web

#### Apache (exemplo de configuração)

```apache
<VirtualHost *:80>
    ServerName escolavistaalegre.com.br
    ServerAlias www.escolavistaalegre.com.br
    DocumentRoot /caminho/para/escolavistaalegre/backend/public

    <Directory "/caminho/para/escolavistaalegre/backend/public">
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/escolavistaalegre-error.log
    CustomLog ${APACHE_LOG_DIR}/escolavistaalegre-access.log combined
</VirtualHost>
```

#### Nginx (exemplo de configuração)

```nginx
server {
    listen 80;
    server_name escolavistaalegre.com.br www.escolavistaalegre.com.br;
    root /caminho/para/escolavistaalegre/backend/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

## Manutenção

### Backup do Sistema

#### Backup do Banco de Dados

Para MySQL:
```bash
mysqldump -u usuario -p escolavistaalegre > backup_$(date +%Y%m%d).sql
```

Para SQLite:
```bash
cp database/database.sqlite database/database_backup_$(date +%Y%m%d).sqlite
```

#### Backup de Arquivos de Upload

```bash
tar -czf storage_backup_$(date +%Y%m%d).tar.gz storage/app/public/
```

### Atualização do Sistema

1. Faça backup do banco de dados e arquivos
2. Atualize o código-fonte:

```bash
git pull origin main
```

3. Atualize as dependências:

```bash
composer install
npm install
npm run build
```

4. Execute migrações pendentes:

```bash
php artisan migrate
```

5. Limpe os caches:

```bash
php artisan cache:clear
php artisan config:clear
php artisan view:clear
```

### Monitoramento e Logs

Os logs do Laravel estão localizados em:
```
/storage/logs/laravel.log
```

Recomenda-se monitorar regularmente este arquivo para identificar possíveis erros.

### Segurança

1. Mantenha o PHP e todas as dependências atualizadas
2. Realize backups regulares
3. Use senhas fortes para usuários administrativos
4. Configure HTTPS para o site em produção
5. Limite o acesso ao painel administrativo por IP, se possível

## Solução de Problemas Comuns

### Erro de Permissão

Se encontrar erros de permissão, verifique se as pastas `storage` e `bootstrap/cache` têm permissões de escrita:

```bash
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

### Erro de Conexão com Banco de Dados

Verifique as configurações no arquivo `.env` e certifique-se de que o banco de dados está acessível.

### Imagens não Aparecem

Verifique se o link simbólico do storage foi criado:

```bash
php artisan storage:link
```

### Painel Administrativo Inacessível

Verifique se o usuário administrador foi criado corretamente e se as rotas do FilamentPHP estão funcionando.

## Suporte Técnico

Para suporte técnico, entre em contato através do e-mail: suporte@escolavistaalegre.com.br
