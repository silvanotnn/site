<?php

require __DIR__.'/vendor/autoload.php';

$app = require_once __DIR__.'/bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use Illuminate\Support\Facades\Hash;

$user = new User();
$user->name = 'Administrador';
$user->email = 'admin@escolavistaalegre.com.br';
$user->password = Hash::make('escola123');
$user->save();

echo "Usuário administrador criado com sucesso!\n";
echo "Email: admin@escolavistaalegre.com.br\n";
echo "Senha: escola123\n";
