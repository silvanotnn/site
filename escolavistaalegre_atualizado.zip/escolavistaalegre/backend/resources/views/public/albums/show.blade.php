@extends('layouts.public')

@section('title', 'Visualizar Álbum')

@section('content')
<!-- Hero Section -->
<section class="hero-section" style="background: linear-gradient(rgba(31, 41, 55, 0.7), rgba(31, 41, 55, 0.7)), url('https://images.unsplash.com/photo-1574629810360-7efbbe195018?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1493&q=80');">
    <div class="container mx-auto px-4">
        <div class="hero-content text-center" data-aos="fade-up">
            <h1 class="hero-title">{{ $album->name ?? 'Álbum de Fotos' }}</h1>
            <p class="hero-subtitle">{{ $album->description ?? 'Galeria de imagens da Escola Vista Alegre' }}</p>
        </div>
    </div>
</section>

<!-- Album Info Section -->
<section class="section">
    <div class="container mx-auto px-4">
        <!-- Breadcrumb -->
        <nav class="mb-8 text-sm" data-aos="fade-up">
            <ol class="flex flex-wrap items-center space-x-2">
                <li class="flex items-center">
                    <a href="{{ route('home') }}" class="text-blue-600 hover:text-blue-800">Início</a>
                    <svg class="w-3 h-3 mx-2 fill-current text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z"/></svg>
                </li>
                <li class="flex items-center">
                    <a href="{{ route('albums') }}" class="text-blue-600 hover:text-blue-800">Álbuns</a>
                    <svg class="w-3 h-3 mx-2 fill-current text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z"/></svg>
                </li>
                <li class="text-gray-600">{{ $album->name ?? 'Álbum' }}</li>
            </ol>
        </nav>

        <!-- Album Details -->
        <div class="bg-white rounded-lg shadow-lg p-8 mb-12" data-aos="fade-up">
            <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
                <div>
                    <h2 class="text-3xl font-bold text-gray-800">{{ $album->name ?? 'Nome do Álbum' }}</h2>
                    <div class="flex items-center text-gray-500 text-sm mt-2">
                        <span class="mr-4">
                            <i class="far fa-calendar-alt mr-1"></i>
                            {{ isset($album) && $album->created_at ? $album->created_at->format('d/m/Y') : date('d/m/Y') }}
                        </span>
                        @if(isset($album) && isset($album->images))
                            <span>
                                <i class="far fa-images mr-1"></i>
                                {{ count($album->images) }} fotos
                            </span>
                        @endif
                    </div>
                </div>
                <a href="{{ route('albums') }}" class="inline-flex items-center text-blue-600 hover:text-blue-800 transition mt-4 md:mt-0">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Voltar para todos os álbuns
                </a>
            </div>
            
            @if(isset($album) && $album->description)
                <p class="text-gray-700">{{ $album->description }}</p>
            @endif
        </div>

        <!-- Photo Gallery -->
        <div class="mb-12">
            @if(isset($album) && isset($album->images) && count($album->images) > 0)
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    @foreach($album->images as $image)
                    <div class="gallery-item" data-aos="zoom-in" data-aos-delay="{{ $loop->iteration * 50 }}">
                        <img src="{{ asset('storage/' . $image->path) }}" alt="{{ $image->caption ?? 'Imagem do álbum' }}" class="gallery-img">
                        <div class="gallery-overlay">
                            <a href="{{ asset('storage/' . $image->path) }}" target="_blank" class="text-white hover:text-yellow-300">
                                <i class="fas fa-search-plus text-3xl"></i>
                            </a>
                        </div>
                        @if($image->caption)
                            <div class="p-4 bg-white">
                                <p class="text-gray-700">{{ $image->caption }}</p>
                            </div>
                        @endif
                    </div>
                    @endforeach
                </div>
            @else
                <div class="bg-white rounded-lg shadow-md p-12 text-center">
                    <i class="fas fa-images text-5xl text-gray-300 mb-4"></i>
                    <h3 class="text-xl font-bold text-gray-700 mb-2">Nenhuma imagem disponível neste álbum</h3>
                    <p class="text-gray-600">Este álbum ainda não possui imagens ou está em processo de atualização.</p>
                </div>
            @endif
        </div>
    </div>
</section>

<!-- Related Albums Section -->
<section class="section bg-light-color">
    <div class="container mx-auto px-4">
        <h2 class="section-title text-center text-3xl mb-12" data-aos="fade-up">Outros Álbuns</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            @for($i = 1; $i <= 3; $i++)
            <div class="card" data-aos="fade-up" data-aos-delay="{{ $i * 100 }}">
                <div class="h-48 bg-gray-300">
                    <img src="https://images.unsplash.com/photo-1577896851231-70ef18881754?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" alt="Álbum relacionado" class="w-full h-full object-cover">
                </div>
                <div class="p-6">
                    <h3 class="card-title text-xl">Álbum Relacionado {{ $i }}</h3>
                    <p class="text-gray-500 text-sm mb-3">{{ date('d/m/Y') }}</p>
                    <p class="card-text mb-4">Descrição breve do álbum relacionado com fotos de eventos e atividades da escola.</p>
                    <a href="{{ route('albums') }}" class="btn-primary inline-block">Ver álbum</a>
                </div>
            </div>
            @endfor
        </div>
        
        <div class="text-center mt-8" data-aos="fade-up">
            <a href="{{ route('albums') }}" class="btn-primary">Ver todos os álbuns</a>
        </div>
    </div>
</section>

<!-- Share Section -->
<section class="section bg-primary-color text-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-6" data-aos="fade-up">Compartilhe este álbum</h2>
        <p class="text-xl mb-8 max-w-3xl mx-auto" data-aos="fade-up" data-aos-delay="100">Gostou das fotos? Compartilhe este álbum com amigos e familiares nas redes sociais.</p>
        <div class="flex justify-center space-x-4" data-aos="fade-up" data-aos-delay="200">
            <a href="#" class="bg-white text-blue-600 w-12 h-12 rounded-full flex items-center justify-center hover:bg-blue-100 transition">
                <i class="fab fa-facebook-f"></i>
            </a>
            <a href="#" class="bg-white text-pink-600 w-12 h-12 rounded-full flex items-center justify-center hover:bg-blue-100 transition">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="#" class="bg-white text-blue-400 w-12 h-12 rounded-full flex items-center justify-center hover:bg-blue-100 transition">
                <i class="fab fa-twitter"></i>
            </a>
            <a href="#" class="bg-white text-green-600 w-12 h-12 rounded-full flex items-center justify-center hover:bg-blue-100 transition">
                <i class="fab fa-whatsapp"></i>
            </a>
        </div>
    </div>
</section>
@endsection
