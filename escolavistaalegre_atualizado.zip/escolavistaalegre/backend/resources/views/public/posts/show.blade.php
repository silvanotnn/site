@extends('layouts.public')

@section('title', 'Visualizar Notícia')

@section('content')
<!-- Hero Section -->
<section class="hero-section" style="background: linear-gradient(rgba(31, 41, 55, 0.7), rgba(31, 41, 55, 0.7)), url('https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1422&q=80');">
    <div class="container mx-auto px-4">
        <div class="hero-content text-center" data-aos="fade-up">
            <h1 class="hero-title">{{ $post->title ?? 'Notícia' }}</h1>
            <p class="hero-subtitle">{{ isset($post) && $post->created_at ? $post->created_at->format('d/m/Y') : date('d/m/Y') }}</p>
        </div>
    </div>
</section>

<!-- Post Content Section -->
<section class="section">
    <div class="container mx-auto px-4">
        <!-- Breadcrumb -->
        <nav class="mb-8 text-sm" data-aos="fade-up">
            <ol class="flex flex-wrap items-center space-x-2">
                <li class="flex items-center">
                    <a href="{{ route('home') }}" class="text-blue-600 hover:text-blue-800">Início</a>
                    <svg class="w-3 h-3 mx-2 fill-current text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z"/></svg>
                </li>
                <li class="flex items-center">
                    <a href="{{ route('posts') }}" class="text-blue-600 hover:text-blue-800">Notícias</a>
                    <svg class="w-3 h-3 mx-2 fill-current text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z"/></svg>
                </li>
                <li class="text-gray-600">{{ $post->title ?? 'Notícia' }}</li>
            </ol>
        </nav>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <!-- Main Content -->
            <div class="lg:col-span-2">
                <article class="bg-white rounded-lg shadow-lg overflow-hidden" data-aos="fade-up">
                    @if(isset($post) && $post->image_path)
                        <div class="h-80 bg-gray-300">
                            <img src="{{ asset('storage/' . $post->image_path) }}" alt="{{ $post->title }}" class="w-full h-full object-cover">
                        </div>
                    @else
                        <div class="h-80 bg-blue-100 flex items-center justify-center">
                            <i class="fas fa-newspaper text-6xl text-blue-500"></i>
                        </div>
                    @endif
                    
                    <div class="p-8">
                        <h1 class="text-3xl font-bold text-gray-800 mb-4">{{ $post->title ?? 'Título da Notícia' }}</h1>
                        
                        <div class="flex items-center text-gray-500 text-sm mb-6 border-b border-gray-200 pb-6">
                            <span class="mr-4">
                                <i class="far fa-calendar-alt mr-1"></i>
                                {{ isset($post) && $post->created_at ? $post->created_at->format('d/m/Y') : date('d/m/Y') }}
                            </span>
                            <span class="mr-4">
                                <i class="far fa-user mr-1"></i>
                                {{ isset($post) && isset($post->user) ? $post->user->name : 'Administrador' }}
                            </span>
                            <span>
                                <i class="far fa-folder mr-1"></i>
                                Notícias
                            </span>
                        </div>
                        
                        <div class="prose max-w-none">
                            @if(isset($post) && $post->content)
                                {!! $post->content !!}
                            @else
                                <p>Conteúdo da notícia não disponível.</p>
                            @endif
                        </div>
                        
                        <!-- Social Share -->
                        <div class="mt-8 pt-6 border-t border-gray-200">
                            <h3 class="text-lg font-bold text-gray-800 mb-4">Compartilhe esta notícia</h3>
                            <div class="flex space-x-3">
                                <a href="#" class="bg-blue-600 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-700 transition">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                                <a href="#" class="bg-blue-400 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-500 transition">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <a href="#" class="bg-green-600 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-green-700 transition">
                                    <i class="fab fa-whatsapp"></i>
                                </a>
                                <a href="#" class="bg-blue-800 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-900 transition">
                                    <i class="fab fa-linkedin-in"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </article>
                
                <!-- Back Button -->
                <div class="mt-8" data-aos="fade-up">
                    <a href="{{ route('posts') }}" class="inline-flex items-center text-blue-600 hover:text-blue-800 transition">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Voltar para todas as notícias
                    </a>
                </div>
            </div>
            
            <!-- Sidebar -->
            <div class="lg:col-span-1">
                <!-- Recent Posts -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-8" data-aos="fade-left">
                    <h3 class="text-xl font-bold text-gray-800 mb-4">Notícias Recentes</h3>
                    <div class="space-y-4">
                        @if(isset($relatedPosts) && count($relatedPosts) > 0)
                            @foreach($relatedPosts as $relatedPost)
                            <div class="flex items-start">
                                <div class="w-20 h-20 bg-gray-300 flex-shrink-0 mr-4">
                                    @if($relatedPost->image_path)
                                        <img src="{{ asset('storage/' . $relatedPost->image_path) }}" alt="{{ $relatedPost->title }}" class="w-full h-full object-cover">
                                    @else
                                        <div class="w-full h-full bg-blue-100 flex items-center justify-center">
                                            <i class="fas fa-newspaper text-blue-500"></i>
                                        </div>
                                    @endif
                                </div>
                                <div>
                                    <h4 class="font-semibold text-gray-800 mb-1">
                                        <a href="{{ route('posts.show', $relatedPost->id) }}" class="hover:text-blue-600 transition">{{ $relatedPost->title }}</a>
                                    </h4>
                                    <p class="text-gray-500 text-sm">{{ $relatedPost->created_at->format('d/m/Y') }}</p>
                                </div>
                            </div>
                            @endforeach
                        @else
                            @for($i = 1; $i <= 3; $i++)
                            <div class="flex items-start">
                                <div class="w-20 h-20 bg-blue-100 flex-shrink-0 mr-4 flex items-center justify-center">
                                    <i class="fas fa-newspaper text-blue-500"></i>
                                </div>
                                <div>
                                    <h4 class="font-semibold text-gray-800 mb-1">
                                        <a href="{{ route('posts') }}" class="hover:text-blue-600 transition">Notícia Recente {{ $i }}</a>
                                    </h4>
                                    <p class="text-gray-500 text-sm">{{ date('d/m/Y') }}</p>
                                </div>
                            </div>
                            @endfor
                        @endif
                    </div>
                </div>
                
                <!-- Categories -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-8" data-aos="fade-left" data-aos-delay="100">
                    <h3 class="text-xl font-bold text-gray-800 mb-4">Categorias</h3>
                    <ul class="space-y-2">
                        <li>
                            <a href="#" class="flex items-center justify-between text-gray-700 hover:text-blue-600 transition">
                                <span>Eventos</span>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-2 py-1 rounded-full">12</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="flex items-center justify-between text-gray-700 hover:text-blue-600 transition">
                                <span>Atividades</span>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-2 py-1 rounded-full">8</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="flex items-center justify-between text-gray-700 hover:text-blue-600 transition">
                                <span>Projetos</span>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-2 py-1 rounded-full">5</span>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="flex items-center justify-between text-gray-700 hover:text-blue-600 transition">
                                <span>Comunicados</span>
                                <span class="bg-blue-100 text-blue-600 text-xs font-semibold px-2 py-1 rounded-full">10</span>
                            </a>
                        </li>
                    </ul>
                </div>
                
                <!-- Tags -->
                <div class="bg-white rounded-lg shadow-md p-6" data-aos="fade-left" data-aos-delay="200">
                    <h3 class="text-xl font-bold text-gray-800 mb-4">Tags</h3>
                    <div class="flex flex-wrap gap-2">
                        <a href="#" class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-blue-100 hover:text-blue-600 transition">Educação</a>
                        <a href="#" class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-blue-100 hover:text-blue-600 transition">Escola</a>
                        <a href="#" class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-blue-100 hover:text-blue-600 transition">Alunos</a>
                        <a href="#" class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-blue-100 hover:text-blue-600 transition">Professores</a>
                        <a href="#" class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-blue-100 hover:text-blue-600 transition">Aprendizagem</a>
                        <a href="#" class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-blue-100 hover:text-blue-600 transition">Atividades</a>
                        <a href="#" class="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-blue-100 hover:text-blue-600 transition">Eventos</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="section bg-primary-color text-white">
    <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold mb-6" data-aos="fade-up">Fique por dentro das novidades</h2>
        <p class="text-xl mb-8 max-w-3xl mx-auto" data-aos="fade-up" data-aos-delay="100">Assine nossa newsletter e receba as últimas notícias, eventos e atualizações da Escola Vista Alegre.</p>
        <div class="max-w-lg mx-auto" data-aos="fade-up" data-aos-delay="200">
            <form action="#" method="POST" class="flex flex-col md:flex-row gap-4">
                <input type="email" placeholder="Seu e-mail" class="flex-grow px-4 py-3 rounded-lg focus:outline-none" required>
                <button type="submit" class="bg-yellow-400 text-primary-dark font-bold py-3 px-6 rounded-lg hover:bg-yellow-300 transition">Assinar</button>
            </form>
        </div>
    </div>
</section>
@endsection
