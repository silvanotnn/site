@extends('layouts.public')

@section('title', 'Contato')

@section('content')
<!-- Hero Section -->
<section class="hero-section" style="background: linear-gradient(rgba(31, 41, 55, 0.7), rgba(31, 41, 55, 0.7)), url('https://images.unsplash.com/photo-1596524430615-b46475ddff6e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80');">
    <div class="container mx-auto px-4">
        <div class="hero-content text-center" data-aos="fade-up">
            <h1 class="hero-title">Entre em Contato</h1>
            <p class="hero-subtitle">Estamos à disposição para atender suas dúvidas, sugestões ou agendamento de visitas</p>
        </div>
    </div>
</section>

<!-- Contact Section -->
<section class="section">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <!-- Contact Form -->
            <div data-aos="fade-right">
                <div class="contact-form">
                    <h2 class="section-title text-2xl mb-8">Envie uma mensagem</h2>
                    
                    @if(session('success'))
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6 flex items-center">
                            <i class="fas fa-check-circle mr-2"></i>
                            <span>{{ session('success') }}</span>
                        </div>
                    @endif
                    
                    <form action="{{ route('contact.send') }}" method="POST" class="space-y-6">
                        @csrf
                        <div>
                            <label for="name" class="form-label block mb-2">Nome completo</label>
                            <input type="text" id="name" name="name" class="form-control w-full" required>
                            @error('name')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>
                        
                        <div>
                            <label for="email" class="form-label block mb-2">E-mail</label>
                            <input type="email" id="email" name="email" class="form-control w-full" required>
                            @error('email')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>
                        
                        <div>
                            <label for="phone" class="form-label block mb-2">Telefone</label>
                            <input type="tel" id="phone" name="phone" class="form-control w-full">
                            @error('phone')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>
                        
                        <div>
                            <label for="subject" class="form-label block mb-2">Assunto</label>
                            <select id="subject" name="subject" class="form-control w-full" required>
                                <option value="">Selecione um assunto</option>
                                <option value="Informações">Informações gerais</option>
                                <option value="Matrícula">Matrícula</option>
                                <option value="Visita">Agendar visita</option>
                                <option value="Sugestão">Sugestão</option>
                                <option value="Outro">Outro</option>
                            </select>
                            @error('subject')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>
                        
                        <div>
                            <label for="message" class="form-label block mb-2">Mensagem</label>
                            <textarea id="message" name="message" rows="5" class="form-control w-full" required></textarea>
                            @error('message')
                                <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                            @enderror
                        </div>
                        
                        <button type="submit" class="btn-primary w-full py-3 text-center">Enviar mensagem</button>
                    </form>
                </div>
            </div>
            
            <!-- Contact Information -->
            <div data-aos="fade-left">
                <div class="bg-white rounded-lg shadow-md p-8 mb-8">
                    <h2 class="section-title text-2xl mb-8">Informações de contato</h2>
                    
                    <div class="space-y-6">
                        <div class="flex items-start">
                            <div class="bg-blue-100 p-3 rounded-full mr-4 flex-shrink-0">
                                <i class="fas fa-map-marker-alt text-blue-600"></i>
                            </div>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-1">Endereço</h3>
                                <p class="text-gray-600">Rua das Flores, 123<br>Vista Alegre - SP<br>CEP: 00000-000</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-blue-100 p-3 rounded-full mr-4 flex-shrink-0">
                                <i class="fas fa-phone-alt text-blue-600"></i>
                            </div>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-1">Telefone</h3>
                                <p class="text-gray-600">(11) 1234-5678</p>
                                <p class="text-gray-600">(11) 98765-4321</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-blue-100 p-3 rounded-full mr-4 flex-shrink-0">
                                <i class="fas fa-envelope text-blue-600"></i>
                            </div>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-1">E-mail</h3>
                                <p class="text-gray-600">contato@escolavistaalegre.com.br</p>
                                <p class="text-gray-600">secretaria@escolavistaalegre.com.br</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-blue-100 p-3 rounded-full mr-4 flex-shrink-0">
                                <i class="fas fa-clock text-blue-600"></i>
                            </div>
                            <div>
                                <h3 class="font-semibold text-gray-800 mb-1">Horário de atendimento</h3>
                                <p class="text-gray-600">Segunda a sexta: 8h às 18h</p>
                                <p class="text-gray-600">Sábado: 8h às 12h</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Social Media -->
                <div class="bg-white rounded-lg shadow-md p-8 mb-8">
                    <h2 class="text-xl font-bold text-gray-800 mb-6">Redes Sociais</h2>
                    <div class="flex space-x-4">
                        <a href="#" class="bg-blue-600 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-700 transition">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="bg-pink-600 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-pink-700 transition">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="bg-blue-400 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-500 transition">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="bg-red-600 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-red-700 transition">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>
                
                <!-- Map -->
                <div class="bg-white rounded-lg shadow-md p-8">
                    <h2 class="text-xl font-bold text-gray-800 mb-6">Localização</h2>
                    <div class="h-64 bg-gray-200 rounded-lg flex items-center justify-center">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.1976900292864!2d-46.65868382378026!3d-23.56135786246454!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59c8da0aa315%3A0xd59f9431f2c9776a!2sAv.%20Paulista%2C%20S%C3%A3o%20Paulo%20-%20SP!5e0!3m2!1spt-BR!2sbr!4v1685984225485!5m2!1spt-BR!2sbr" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="section bg-light-color">
    <div class="container mx-auto px-4">
        <h2 class="section-title text-center text-3xl mb-12" data-aos="fade-up">Perguntas Frequentes</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="bg-white rounded-lg shadow-md p-6" data-aos="fade-up" data-aos-delay="100">
                <h3 class="text-xl font-bold text-gray-800 mb-3">Como faço para matricular meu filho?</h3>
                <p class="text-gray-700">Para matricular seu filho, entre em contato conosco através do formulário ou telefone para agendar uma visita. Durante a visita, apresentaremos a escola e forneceremos todas as informações sobre o processo de matrícula.</p>
            </div>
            
            <div class="bg-white rounded-lg shadow-md p-6" data-aos="fade-up" data-aos-delay="200">
                <h3 class="text-xl font-bold text-gray-800 mb-3">Quais são os horários de aula?</h3>
                <p class="text-gray-700">As aulas ocorrem de segunda a sexta-feira, nos períodos da manhã (7h30 às 12h) e da tarde (13h30 às 18h). Oferecemos também atividades extracurriculares no contraturno.</p>
            </div>
            
            <div class="bg-white rounded-lg shadow-md p-6" data-aos="fade-up" data-aos-delay="300">
                <h3 class="text-xl font-bold text-gray-800 mb-3">A escola oferece alimentação?</h3>
                <p class="text-gray-700">Sim, oferecemos alimentação balanceada e supervisionada por nutricionistas. Os cardápios são elaborados mensalmente e disponibilizados aos pais.</p>
            </div>
            
            <div class="bg-white rounded-lg shadow-md p-6" data-aos="fade-up" data-aos-delay="400">
                <h3 class="text-xl font-bold text-gray-800 mb-3">Quais atividades extracurriculares são oferecidas?</h3>
                <p class="text-gray-700">Oferecemos diversas atividades extracurriculares, como esportes, música, teatro, dança, robótica e idiomas. As atividades variam conforme a faixa etária e são opcionais.</p>
            </div>
        </div>
    </div>
</section>
@endsection
