<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Album;

class HomeController extends Controller
{
    public function index()
    {
        // Buscar as últimas postagens
        $posts = Post::latest()->take(3)->get();
        
        // Buscar os últimos álbuns
        $albums = Album::latest()->take(4)->get();
        
        return view('public.home', compact('posts', 'albums'));
    }
}
