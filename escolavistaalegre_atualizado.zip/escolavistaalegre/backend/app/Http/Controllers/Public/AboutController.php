<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\InstitutionalText;

class AboutController extends Controller
{
    public function index()
    {
        // Buscar textos institucionais
        $about = InstitutionalText::where('key', 'about_us')->first();
        $mission = InstitutionalText::where('key', 'mission')->first();
        $vision = InstitutionalText::where('key', 'vision')->first();
        $values = InstitutionalText::where('key', 'values')->first();
        
        return view('public.about', compact('about', 'mission', 'vision', 'values'));
    }
}
