<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Public\HomeController;
use App\Http\Controllers\Public\AboutController;
use App\Http\Controllers\Public\PostController;
use App\Http\Controllers\Public\AlbumController;
use App\Http\Controllers\Public\ContactController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Rotas públicas
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/sobre', [AboutController::class, 'index'])->name('about');

// Rotas de postagens
Route::get('/noticias', [PostController::class, 'index'])->name('posts');
Route::get('/noticias/{post}', [PostController::class, 'show'])->name('posts.show');

// Rotas de álbuns
Route::get('/albuns', [AlbumController::class, 'index'])->name('albums');
Route::get('/albuns/{album}', [AlbumController::class, 'show'])->name('albums.show');

// Rotas de contato
Route::get('/contato', [ContactController::class, 'index'])->name('contact');
Route::post('/contato/enviar', [ContactController::class, 'send'])->name('contact.send');
