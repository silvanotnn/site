@extends('layouts.public')

@section('title', 'Notícias')

@section('content')
<!-- Hero Section -->
<section class="hero-section" style="background: linear-gradient(rgba(31, 41, 55, 0.7), rgba(31, 41, 55, 0.7)), url('https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1422&q=80');">
    <div class="container mx-auto px-4">
        <div class="hero-content text-center" data-aos="fade-up">
            <h1 class="hero-title">Notícias e Eventos</h1>
            <p class="hero-subtitle">Acompanhe as últimas novidades, eventos e acontecimentos da Escola Vista Alegre</p>
        </div>
    </div>
</section>

<!-- Posts List Section -->
<section class="section">
    <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            @if(isset($posts) && count($posts) > 0)
                @foreach($posts as $post)
                <div class="card" data-aos="fade-up" data-aos-delay="{{ $loop->iteration * 100 }}">
                    <div class="h-48 bg-gray-300 flex items-center justify-center">
                        @if($post->image_path)
                            <img src="{{ asset('storage/' . $post->image_path) }}" alt="{{ $post->title }}" class="w-full h-full object-cover">
                        @else
                            <div class="w-full h-full bg-blue-100 flex items-center justify-center">
                                <i class="fas fa-newspaper text-4xl text-blue-500"></i>
                            </div>
                        @endif
                    </div>
                    <div class="p-6">
                        <h3 class="card-title text-xl">{{ $post->title }}</h3>
                        <div class="flex items-center text-gray-500 text-sm mb-3">
                            <span class="mr-4">
                                <i class="far fa-calendar-alt mr-1"></i>
                                {{ $post->created_at->format('d/m/Y') }}
                            </span>
                            @if(isset($post->user))
                            <span>
                                <i class="far fa-user mr-1"></i>
                                {{ $post->user->name }}
                            </span>
                            @endif
                        </div>
                        <p class="card-text mb-4">{{ \Illuminate\Support\Str::limit(strip_tags($post->content), 150) }}</p>
                        <a href="{{ route('posts.show', $post->id) }}" class="btn-primary inline-block">Leia mais</a>
                    </div>
                </div>
                @endforeach
            @else
                <div class="col-span-3 text-center py-12" data-aos="fade-up">
                    <div class="bg-white rounded-lg shadow-md p-8">
                        <i class="fas fa-newspaper text-5xl text-gray-300 mb-4"></i>
                        <h3 class="text-xl font-bold text-gray-700 mb-2">Nenhuma notícia disponível</h3>
                        <p class="text-gray-600">Volte em breve para conferir as novidades da nossa escola.</p>
                    </div>
                </div>
            @endif
        </div>

        <!-- Pagination -->
        @if(isset($posts) && $posts->hasPages())
        <div class="mt-12 flex justify-center" data-aos="fade-up">
            <nav class="inline-flex rounded-md shadow">
                @if($posts->onFirstPage())
                    <span class="px-4 py-2 bg-gray-200 text-gray-500 rounded-l-md">Anterior</span>
                @else
                    <a href="{{ $posts->previousPageUrl() }}" class="px-4 py-2 bg-white text-blue-600 hover:bg-blue-50 rounded-l-md">Anterior</a>
                @endif
                
                <span class="px-4 py-2 bg-blue-600 text-white">{{ $posts->currentPage() }}</span>
                
                @if($posts->hasMorePages())
                    <a href="{{ $posts->nextPageUrl() }}" class="px-4 py-2 bg-white text-blue-600 hover:bg-blue-50 rounded-r-md">Próxima</a>
                @else
                    <span class="px-4 py-2 bg-gray-200 text-gray-500 rounded-r-md">Próxima</span>
                @endif
            </nav>
        </div>
        @endif
    </div>
</section>

<!-- Newsletter Section -->
<section class="section bg-light-color">
    <div class="container mx-auto px-4">
        <div class="bg-white rounded-lg shadow-lg p-8 md:p-12" data-aos="fade-up">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                    <h2 class="text-3xl font-bold mb-4">Fique por dentro das novidades</h2>
                    <p class="text-gray-700 mb-6">Assine nossa newsletter e receba as últimas notícias, eventos e atualizações da Escola Vista Alegre diretamente no seu e-mail.</p>
                </div>
                <div>
                    <form action="#" method="POST" class="space-y-4">
                        <div class="flex flex-col md:flex-row gap-4">
                            <input type="email" placeholder="Seu e-mail" class="form-control flex-grow" required>
                            <button type="submit" class="btn-primary whitespace-nowrap">Assinar Newsletter</button>
                        </div>
                        <p class="text-sm text-gray-500">Respeitamos sua privacidade. Você pode cancelar a assinatura a qualquer momento.</p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
