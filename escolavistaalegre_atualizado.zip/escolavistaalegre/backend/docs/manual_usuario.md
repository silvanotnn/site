# Manual do Usuário - Escola Vista Alegre

## Introdução

Bem-vindo ao sistema de gerenciamento de conteúdo da Escola Vista Alegre. Este manual foi desenvolvido para auxiliar administradores na utilização do painel administrativo para gerenciar o conteúdo do site institucional.

## Acesso ao Painel Administrativo

1. Acesse o site da Escola Vista Alegre
2. Navegue até `/adminadmin` na URL (exemplo: `https://escolavistaalegre.com.br/adminadmin`)
3. Insira suas credenciais de acesso (e-mail e senha)
4. Clique em "Entrar"

## Gerenciamento de Postagens (Notícias)

### Visualizar Todas as Postagens

1. No menu lateral, clique em "Postagens"
2. Você verá uma lista com todas as postagens existentes
3. Utilize os filtros e a barra de pesquisa para encontrar postagens específicas

### Criar Nova Postagem

1. Na página de listagem de postagens, clique no botão "Nova Postagem"
2. Preencha os campos obrigatórios:
   - Título: título da postagem
   - Conteúdo: texto completo da postagem (editor rico disponível)
   - Imagem: faça upload de uma imagem para ilustrar a postagem (opcional)
3. Clique em "Salvar" para publicar a postagem

### Editar Postagem Existente

1. Na lista de postagens, encontre a postagem que deseja editar
2. Clique no ícone de edição (lápis) na coluna de ações
3. Faça as alterações necessárias nos campos
4. Clique em "Salvar" para atualizar a postagem

### Excluir Postagem

1. Na lista de postagens, encontre a postagem que deseja excluir
2. Clique no ícone de exclusão (lixeira) na coluna de ações
3. Confirme a exclusão na caixa de diálogo que aparecerá

## Gerenciamento de Álbuns de Fotos

### Visualizar Todos os Álbuns

1. No menu lateral, clique em "Álbuns"
2. Você verá uma lista com todos os álbuns existentes
3. Utilize os filtros e a barra de pesquisa para encontrar álbuns específicos

### Criar Novo Álbum

1. Na página de listagem de álbuns, clique no botão "Novo Álbum"
2. Preencha os campos obrigatórios:
   - Nome: título do álbum
   - Descrição: breve descrição do álbum (opcional)
3. Clique em "Salvar" para criar o álbum

### Adicionar Imagens ao Álbum

1. Na lista de álbuns, encontre o álbum ao qual deseja adicionar imagens
2. Clique no ícone de gerenciamento de imagens na coluna de ações
3. Clique no botão "Adicionar Imagens"
4. Selecione uma ou múltiplas imagens para upload
5. Para cada imagem, você pode adicionar uma legenda (opcional)
6. Clique em "Salvar" para adicionar as imagens ao álbum

### Editar Álbum Existente

1. Na lista de álbuns, encontre o álbum que deseja editar
2. Clique no ícone de edição (lápis) na coluna de ações
3. Faça as alterações necessárias nos campos
4. Clique em "Salvar" para atualizar o álbum

### Excluir Álbum

1. Na lista de álbuns, encontre o álbum que deseja excluir
2. Clique no ícone de exclusão (lixeira) na coluna de ações
3. Confirme a exclusão na caixa de diálogo que aparecerá
   - **Atenção**: Excluir um álbum também excluirá todas as imagens associadas a ele

## Gerenciamento de Textos Institucionais

### Editar Textos da Página "Sobre"

1. No menu lateral, clique em "Textos Institucionais"
2. Você verá uma lista com todos os textos institucionais disponíveis
3. Encontre o texto que deseja editar (ex: "about_us", "mission", "vision", "values")
4. Clique no ícone de edição (lápis) na coluna de ações
5. Faça as alterações necessárias no campo de conteúdo
6. Clique em "Salvar" para atualizar o texto

## Gerenciamento de Usuários Administrativos

### Visualizar Todos os Usuários

1. No menu lateral, clique em "Usuários"
2. Você verá uma lista com todos os usuários administrativos

### Criar Novo Usuário

1. Na página de listagem de usuários, clique no botão "Novo Usuário"
2. Preencha os campos obrigatórios:
   - Nome: nome completo do usuário
   - E-mail: endereço de e-mail (será usado para login)
   - Senha: senha de acesso
   - Confirmação de Senha: repita a senha para confirmação
3. Clique em "Salvar" para criar o usuário

### Editar Usuário Existente

1. Na lista de usuários, encontre o usuário que deseja editar
2. Clique no ícone de edição (lápis) na coluna de ações
3. Faça as alterações necessárias nos campos
4. Clique em "Salvar" para atualizar o usuário

### Excluir Usuário

1. Na lista de usuários, encontre o usuário que deseja excluir
2. Clique no ícone de exclusão (lixeira) na coluna de ações
3. Confirme a exclusão na caixa de diálogo que aparecerá

## Dicas e Boas Práticas

1. **Imagens**: Utilize imagens com boa resolução, mas otimizadas para web (tamanho máximo recomendado: 5MB)
2. **Formatação de Texto**: Utilize as ferramentas de formatação do editor rico para criar conteúdo bem estruturado
3. **Backup**: Faça backup regular do banco de dados e dos arquivos de mídia
4. **Segurança**: Altere sua senha periodicamente e não compartilhe suas credenciais

## Suporte

Em caso de dúvidas ou problemas técnicos, entre em contato com o suporte técnico através do e-mail: suporte@escolavistaalegre.com.br
